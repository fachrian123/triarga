<?php 

    $dicari = $_POST['cari'];
    header('Location:../?hal=cari&q='.$dicari);

?>