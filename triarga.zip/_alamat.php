<div class="container" style="margin-top: 100px;">
    <iframe class="w-100" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3979.541648038441!2d98.21859417364485!3d4.113207195860575!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x303713fe1d1632a9%3A0xf5d6a9f6a5a08f67!2sTriarga%20Fashion%20%26%20Collection!5e0!3m2!1sen!2sid!4v1713453697691!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        <h5>Alamat triarga : Jalan Karya, Beras Basah, Kecamatan Pangkalan Susu, 
        Kabupaten Langkat, Sumatera Utara </h5>
</div>