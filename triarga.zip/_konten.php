<div class="container" style="margin-top: 80px;">
            <div class="row gy-4 justify-content-center">
    
                <div class="col col-sm-4 text-center">
                    <div class="card mx-auto" style="width: 80%;">
                        <img class="w-100" src="https://lh3.google.com/u/0/d/1Wit3wmtl0Efitjcau0VWku-Vgy6Z0It0=w1907-h896-iv1" alt="hitamcorakdepan">
                        <div class="card-body">
                          <h5 class="card-title">Sevenkey Peach</h5>
                          <p class="card-text">Rp85.000 - 95.000</p>
                          <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                        </div>
                    </div>
                </div>
    
                <div class="col col-sm-4 text-center">
                    <div class="card mx-auto" style="width: 80%;">
                        <img class="w-100" src="https://lh3.google.com/u/0/d/1DLArXU9g-sa97AdRXN_RqVV5mwsoLA9V=w1907-h896-iv1" alt="hitamcorakdepan">
                        <div class="card-body">
                          <h5 class="card-title">Sevenkey Hitam</h5>
                          <p class="card-text">Rp85.000 - 95.000</p>
                          <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                        </div>
                    </div>
                </div>
    
                <div class="col col-sm-4 text-center">
                    <div class="card mx-auto" style="width: 80%;">
                        <img class="w-100" src="https://lh3.google.com/u/0/d/1AvMoEa26xAEbnujuWz_iHHsxBwvTR3Nd=w1907-h896-iv1" alt="hitamcorakdepan">
                        <div class="card-body">
                          <h5 class="card-title">Sevenkey Biru</h5>
                          <p class="card-text">Rp85.000 - 95.000</p>
                          <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                        </div>
                    </div>
                </div>
    
                <div class="col col-sm-4 text-center">
                    <div class="card mx-auto" style="width: 80%;">
                        <img class="w-100" src="https://lh3.google.com/u/0/d/19yBL-kegL-2oTvPyxd6GBhkLDLL9ZxGo=w1907-h896-iv1" alt="hitamcorakdepan">
                        <div class="card-body">
                          <h5 class="card-title">Sevenkey Cream</h5>
                          <p class="card-text">Rp85.000 - 95.000</p>
                          <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                        </div>
                    </div>
                </div>
    
                <div class="col col-sm-4 text-center">
                    <div class="card mx-auto" style="width: 80%;">
                        <img class="w-100" src="https://lh3.google.com/u/0/d/1EfC4Nc_Pu8-dzB33TOuKaCovLMfZ8Lsv=w1907-h896-iv1" alt="hitamcorakdepan">
                        <div class="card-body">
                          <h5 class="card-title">Outside</h5>
                          <p class="card-text">Rp85.000 - 95.000</p>
                          <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                        </div>
                    </div>
                </div>

                <div class="col col-sm-4 text-center">
                  <div class="card mx-auto" style="width: 80%;">
                      <img class="w-100" src="https://lh3.google.com/u/0/d/1yBS-LI1oLKU-JCwkOk8cSUAYQGkYH0iG=w1907-h896-iv1" alt="hitamcorakdepan">
                      <div class="card-body">
                        <h5 class="card-title">Celana pendek</h5>
                        <p class="card-text">Rp85.000 - 95.000</p>
                        <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                      </div>
                  </div>
                </div>

                <div class="col col-sm-4 text-center">
                  <div class="card mx-auto" style="width: 80%;">
                      <img class="w-100" src="https://lh3.google.com/u/0/d/1j1y5NtOXkNQ5_Ek05kgkEsGJOZkvYYeU=w1907-h896-iv1" alt="hitamcorakdepan">
                      <div class="card-body">
                        <h5 class="card-title">Celana jeans</h5>
                        <p class="card-text">Rp85.000 - 95.000</p>
                        <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                      </div>
                  </div>
                </div>

                <div class="col col-sm-4 text-center">
                  <div class="card mx-auto" style="width: 80%;">
                      <img class="w-100" src="https://lh3.google.com/u/0/d/1iRH2HCQa_fqm1t1Vbe6kUUTvIi2Aib9O=w1907-h896-iv1" alt="hitamcorakdepan">
                      <div class="card-body">
                        <h5 class="card-title">Celana jeans</h5>
                        <p class="card-text">Rp85.000 - 95.000</p>
                        <a href="detail_barang.html" class="btn btn-warning w-100">Beli</a>
                      </div>
                  </div>
                </div>
    
            </div>
        </div>

  <!-- Modal keranjang --> 
  <div class="modal fade" id="keranjang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Keranjangku</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <table class="table">
                <thead class="text-center">
                  <tr>
                    <th scope="col">Id barang</th>
                    <th scope="col">Nama barang</th>
                    <th scope="col">@</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Sub total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Sevenkey Hitam Corak (XL)</td>
                    <td>Rp.95.000,00</td>
                    <td>1</td>
                    <td>Rp.95.000,00</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Sevenkey Hitam Corak (L)</td>
                    <td>Rp.55.000,00</td>
                    <td>2</td>
                    <td>Rp.110.000,00</td>
                  </tr>
                </tbody>
              </table>
        </div>
        <div style="justify-content: space-between;" class="modal-footer float-none">
            <h5>Total : Rp.165.000,00</h5>
            
            <button type="button" class="btn btn-primary">Checkout</button>
        </div>
      </div>
    </div>
  </div>
<!--modal detail barang-->
  <div class="modal fade" id="detailBarang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Detail Barang</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!--carousel barang-->
          <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="https://lh4.google.com/u/0/d/1KcVZSyfdmAcTHMnHrgqrxCz_IjL9Wh7C=w1908-h897-iv2" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AKGpihZpLpN0CYrJPszxLOrjWd2Zm27mYp11wS90fNqKagR4R3JeGrAK640MvKX-8K4uZ6vGtXaZoEIhb9aDgx6IrXwypKsxKkWWrxo=w1908-h897-rw-v1" class="d-block w-100" alt="...">
              </div>
              
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
        <!--deskripsi-->
        <h5 class="text-center">Sevenkey Hitam Corak</h5>
        <!--radio button ukuran-->
        <div class="container" style="width:fit-content;">
          <div class="row">
            <div class="col">
              <div class="form-check">
                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="80.000,00" onclick="updateNilai(this.value)">
                <label class="form-check-label" for="flexRadioDefault1">
                  L
                </label>
              </div>
            </div>
            <div class="col">
              <div class="form-check">
                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" value="95.000,00" onclick="updateNilai(this.value)">
                <label class="form-check-label" for="flexRadioDefault2">
                  XL
                </label>
              </div>
            </div>
          </div>
        </div>

        <div style="justify-content: space-between;" class="modal-footer float-none">
          <h5>Harga : Rp.  <span id="nilai_terpilih">Pilih Ukuran</span></h5>
          <button type="button" class="btn btn-primary">Beli Langsung</button>
          <button type="button" class="btn btn-primary">+ Keranjang</button>
        </div>
      </div>
    </div>
  </div>
